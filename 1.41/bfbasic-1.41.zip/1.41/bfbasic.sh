#! /bin/sh
java -jar bfbasic.jar $*
